# Corrección del error «ThreeOneOSFive.xcodeproj does not exist»

El flujo anterior extraía el ZIP en `proyecto/` pero ejecutaba `xcodebuild` suponiendo que el proyecto estaba directamente allí. En realidad, el proyecto está anidado en `proyecto/claro-bb-main/ThreeOneOSFive.xcodeproj`.

El nuevo `scripts/build-unsigned-ipa.sh`:
- busca el proyecto recursivamente, sin asumir una carpeta fija;
- si no encuentra un proyecto extraído, busca ZIPs del repositorio, los extrae en una carpeta temporal y vuelve a buscar;
- pasa a `xcodebuild` la ruta completa del `.xcodeproj`;
- guarda el log aunque la compilación falle.

En GitHub Actions ejecuta **Panther iOS - Build IPA (ruta corregida)** desde la pestaña Actions.

El IPA generado es sin firma. Para instalarlo en un iPhone se necesita firmarlo con un certificado y perfil de aprovisionamiento válidos de Apple.
