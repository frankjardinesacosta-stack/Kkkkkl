# Generar el IPA desde GitHub

1. Descomprime este ZIP.
2. Abre la carpeta `claro-bb-main` y sube **todo su contenido** a la raíz de tu repositorio GitHub (incluye `.github` y `scripts`). No dejes una carpeta extra por encima.
3. En GitHub entra en **Actions**.
4. Selecciona **Panther iOS - Compilar IPA (nuevo)** y pulsa **Run workflow**.
5. Cuando termine, descarga el artefacto **Panther-iOS-IPA-FIRMABLE**. Si falla, descarga **Panther-iOS-LOG** y comparte el archivo para revisar el error concreto.

El flujo localiza `ThreeOneOSFive.xcodeproj` aunque esté dentro de una carpeta contenedora, detecta el scheme/target, resuelve dependencias, compila en macOS y empaqueta la app como IPA.

**Importante:** este flujo genera un IPA sin firmar. No es instalable normalmente hasta firmarlo con un certificado Apple y un perfil de aprovisionamiento válidos. No se incluyen certificados ni credenciales.
