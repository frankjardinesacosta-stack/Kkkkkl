#!/usr/bin/env bash
set -Eeuo pipefail

WORKSPACE="${GITHUB_WORKSPACE:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SEARCH_ROOT="$WORKSPACE"
OUTPUT_DIR="$WORKSPACE"
BUILD_DIR="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/panther-ios-build"
IPA_NAME="${IPA_NAME:-Panther-iOS-FIRMABLE.ipa}"
LOG_FILE="$OUTPUT_DIR/panther-ios-build.log"

fail() { echo "::error::$*" >&2; exit 1; }

mkdir -p "$BUILD_DIR"
: > "$LOG_FILE"
exec > >(tee -a "$LOG_FILE") 2>&1

command -v xcodebuild >/dev/null 2>&1 || fail "Este flujo necesita un runner macOS con Xcode."
command -v python3 >/dev/null 2>&1 || fail "Python 3 no está disponible."

find_project() {
  find "$SEARCH_ROOT" \
    \( -path '*/.git' -o -path '*/.build' -o -path '*/DerivedData' \) -prune -o \
    -type d -name 'ThreeOneOSFive.xcodeproj' -print
}

mapfile -t PROJECTS < <(find_project)

# Si el repositorio contiene el proyecto empaquetado en un ZIP, extraerlo
# a una carpeta temporal y volver a buscarlo recursivamente.
if [[ ${#PROJECTS[@]} -eq 0 ]]; then
  echo "No hay .xcodeproj suelto. Buscando ZIPs que contengan el proyecto..."
  EXTRACT_ROOT="$BUILD_DIR/source-extracted"
  mkdir -p "$EXTRACT_ROOT"
  while IFS= read -r -d '' archive; do
    echo "Revisando: $archive"
    mkdir -p "$EXTRACT_ROOT/$(basename "$archive" .zip)"
    if ! /usr/bin/unzip -oq "$archive" -d "$EXTRACT_ROOT/$(basename "$archive" .zip)"; then
      echo "Aviso: no se pudo extraer $archive; se continúa con los demás."
    fi
  done < <(find "$WORKSPACE" -type f -iname '*.zip' -not -path '*/.git/*' -print0)
  SEARCH_ROOT="$EXTRACT_ROOT"
  mapfile -t PROJECTS < <(find_project)
fi

if [[ ${#PROJECTS[@]} -eq 0 ]]; then
  echo "Archivos disponibles en la raíz:"
  ls -la "$WORKSPACE"
  fail "No se encontró ThreeOneOSFive.xcodeproj ni dentro de los ZIP. Sube el proyecto completo o su ZIP."
fi
if [[ ${#PROJECTS[@]} -gt 1 ]]; then
  printf 'Proyectos encontrados:\n'
  printf ' - %s\n' "${PROJECTS[@]}"
  fail "Se encontraron varios proyectos ThreeOneOSFive.xcodeproj. Deja solo la versión que quieres compilar."
fi

PROJECT="${PROJECTS[0]}"
PROJECT_DIR="$(cd "$(dirname "$PROJECT")" && pwd)"
PROJECT="$(cd "$PROJECT_DIR" && pwd)/$(basename "$PROJECT")"

echo "Workspace: $WORKSPACE"
echo "Carpeta de búsqueda: $SEARCH_ROOT"
echo "Proyecto Xcode: $PROJECT"
echo "Directorio de trabajo: $PROJECT_DIR"
xcodebuild -version

if ! xcodebuild -list -json -project "$PROJECT" > "$BUILD_DIR/project-list.json"; then
  fail "Xcode encontró el proyecto, pero no pudo leerlo. Revisa project.pbxproj."
fi

SCHEME="$(python3 - "$BUILD_DIR/project-list.json" <<'PY'
import json, sys
with open(sys.argv[1], encoding='utf-8') as f:
    data = json.load(f)
p = data.get("project", {})
schemes = p.get("schemes") or []
if not schemes:
    schemes = p.get("targets") or []
if not schemes:
    raise SystemExit("El proyecto no declara schemes ni targets.")
print("3105" if "3105" in schemes else schemes[0])
PY
)" || fail "No se pudo detectar un scheme válido."
echo "Scheme seleccionado: $SCHEME"

xcodebuild -resolvePackageDependencies -project "$PROJECT" -scheme "$SCHEME" || \
  fail "Falló la resolución de paquetes Swift."

set +e
xcodebuild build \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$BUILD_DIR/DerivedData" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY= \
  2>&1 | tee -a "$LOG_FILE"
BUILD_STATUS=${PIPESTATUS[0]}
set -e
if [[ "$BUILD_STATUS" -ne 0 ]]; then
  fail "xcodebuild falló con código $BUILD_STATUS. Consulta el artefacto Panther-iOS-LOG."
fi

PRODUCTS="$BUILD_DIR/DerivedData/Build/Products/Release-iphoneos"
APP="$(find "$PRODUCTS" -maxdepth 1 -type d -name '*.app' -print -quit 2>/dev/null || true)"
[[ -n "$APP" && -d "$APP" ]] || fail "La compilación terminó, pero no se encontró el .app en $PRODUCTS."

STAGING="$BUILD_DIR/ipa-staging"
rm -rf "$STAGING"
mkdir -p "$STAGING/Payload"
ditto "$APP" "$STAGING/Payload/$(basename "$APP")"
rm -f "$OUTPUT_DIR/$IPA_NAME"
(cd "$STAGING" && /usr/bin/zip -qry "$OUTPUT_DIR/$IPA_NAME" Payload)
/usr/bin/unzip -t "$OUTPUT_DIR/$IPA_NAME" | tail -n 1
echo "IPA creado: $OUTPUT_DIR/$IPA_NAME"
echo "IMPORTANTE: este IPA está SIN FIRMAR; requiere certificado y perfil Apple válidos para instalarse."
